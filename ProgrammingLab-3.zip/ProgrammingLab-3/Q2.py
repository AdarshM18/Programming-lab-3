# Given two large vectors v1, v2 of size 106, write Python functions using NumPy that:
#  a. Compute the dot product of these vectors using vectorized operations.
#  b. Compute the same dot product using a scalar (element-wise) approach in a loop.
#  c. Measure and compare the execution time of both approaches, explaining why vec
# torized computation is typically more efficient.


import numpy as np
import time

# Create two large vectors v1 and v2 of size 106
v1 = np.random.rand(106)
v2 = np.random.rand(106)

# a. Compute the dot product using vectorized operations
def dot_product_vectorized(v1, v2):
    return np.dot(v1, v2)

# b. Compute the same dot product using a scalar (element-wise) approach in a loop
def dot_product_scalar(v1, v2):
    result = 0.0
    for i in range(len(v1)):
        result += v1[i] * v2[i]
    return result

# Measure and compare execution times
def measure_times():
    # Time the vectorized approach
    start_time = time.time()
    result_vectorized = dot_product_vectorized(v1, v2)
    vectorized_time = time.time() - start_time

    # Time the scalar approach
    start_time = time.time()
    result_scalar = dot_product_scalar(v1, v2)
    scalar_time = time.time() - start_time

    # Print results and timings
    print(f"Dot product (vectorized) result: {result_vectorized}")
    print(f"Dot product (scalar) result: {result_scalar}")
    print(f"Time taken for vectorized computation: {vectorized_time:.6f} seconds")
    print(f"Time taken for scalar computation: {scalar_time:.6f} seconds")

measure_times()
