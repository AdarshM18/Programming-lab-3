#  Read a large text file. This program’s objective is to count the frequency of each word,
#  ignoring the case. Your code should handle exceptions such as files not being found,
#  ignoring common stopwords, etc.
#  • Output: A dictionary with words as keys and their frequency as values.

import os
import string
from collections import defaultdict

stopwords = set([
    'the', 'is', 'in', 'and', 'to', 'of', 'a', 'that', 'it', 'on', 'was', 
    'he', 'she', 'with', 'as', 'for', 'his', 'they', 'at', 'by', 'an',
    'be', 'this', 'from', 'or', 'but', 'not', 'are', 'we', 'which', 'you',
    'have', 'her', 'has', 'there', 'their', 'can', 'all', 'its', 'if', 'my',
    'one', 'about', 'so', 'when', 'them', 'no', 'what', 'who', 'will', 'would'
])

def count_word_frequency(file_path):
    word_freq = defaultdict(int)

    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            for line in file:
                line = line.translate(str.maketrans('', '', string.punctuation)).lower()
                words = line.split()
         
                for word in words:
                    if word not in stopwords:
                        word_freq[word] += 1

    except FileNotFoundError:
        print(f"Error: The file '{file_path}' was not found.")
        return None

    except Exception as e:
        print(f"An error occurred: {e}")
        return None

    return dict(word_freq)

file_path = 'large_text_file.txt'
word_frequency = count_word_frequency(file_path)

if word_frequency:
    print(word_frequency)
