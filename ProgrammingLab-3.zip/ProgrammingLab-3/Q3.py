#  Write a Python script that performs the following tasks on two large matrices A and B
#  (e.g., 1000 × 1000):
#  a. Using vectorised operations, perform element-wise operations (addition, subtrac
# tion, multiplication, division) between the matrices.
#  b. Use broadcasting to perform operations between a matrix and a vector (e.g., adding
#  a vector to each row or column of a matrix).
#  c. Implement custom operations that combine vectorized operations and broadcasting
#  (e.g., scaling each matrix row by a different scalar).


import numpy as np

# Set the random seed for reproducibility
np.random.seed(0)

# Create two large matrices A and B (e.g., 1000 × 1000)
A = np.random.rand(1000, 1000)
B = np.random.rand(1000, 1000)

# a. Perform element-wise operations using vectorized operations
addition = A + B
subtraction = A - B
multiplication = A * B
division = A / (B + 1e-10)  # Adding a small number to avoid division by zero

print("Element-wise addition completed.")
print("Element-wise subtraction completed.")
print("Element-wise multiplication completed.")
print("Element-wise division completed.")

# b. Use broadcasting to perform operations between a matrix and a vector
vector = np.random.rand(1000)  # Vector with length 1000

# Adding the vector to each row of the matrix
matrix_row_addition = A + vector

# Adding the vector to each column of the matrix
matrix_col_addition = A + vector[:, np.newaxis]

print("Matrix row addition with vector completed.")
print("Matrix column addition with vector completed.")

# c. Implement custom operations combining vectorized operations and broadcasting

# Example: Scaling each row of the matrix A by a different scalar
row_scalars = np.random.rand(1000)  # One scalar for each row
scaled_matrix = A * row_scalars[:, np.newaxis]

# Example: Scaling each column of the matrix B by a different scalar
col_scalars = np.random.rand(1000)  # One scalar for each column
scaled_matrix_B = B * col_scalars

print("Custom row scaling operation completed.")
print("Custom column scaling operation completed.")
