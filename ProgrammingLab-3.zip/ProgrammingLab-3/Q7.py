# Write a code snippet in Python that reads a text file containing a list of email addresses
# and returns a dictionary with the domain names as keys and a list of usernames as values.
# Ensure that the email addresses are valid using regular expressions.
#  • File content: ["user1@iiti.ac.in", "user2@gmail.com", "user3@iiti.ac.in"]
# • Output: {"iiti.ac.in": ["user1", "user3"], "gmail.com": ["user2"]}

import re
from collections import defaultdict

def extract_emails(file_path):
    # Regular expression for validating an Email
    email_regex = re.compile(r'^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$')

    # Dictionary to store domain names and corresponding usernames
    domain_dict = defaultdict(list)

    try:
        # Read the file line by line
        with open(file_path, 'r', encoding='utf-8') as file:
            for line in file:
                line = line.strip()
                
                # Check if the email address is valid
                if email_regex.match(line):
                    # Split the email into username and domain
                    username, domain = line.split('@')
                    
                    # Append the username to the corresponding domain in the dictionary
                    domain_dict[domain].append(username)
                else:
                    print(f"Invalid email address found: {line}")
    
    except FileNotFoundError:
        print(f"Error: The file '{file_path}' was not found.")
        return None
    
    except Exception as e:
        print(f"An error occurred: {e}")
        return None

    return dict(domain_dict)

# Example usage:
file_path = 'emails.txt'
email_domains = extract_emails(file_path)

if email_domains:
    print(email_domains)
