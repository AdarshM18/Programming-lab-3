#  In large datasets, Singular Value Decomposition (SVD) is often used for dimensionality
#  reduction. Implement a function that performs SVD on a given matrix. The function
#  should:
#  a. Decompose the matrix A into three matrices U, Σ, and V T such that A = UΣVT.
#  b. Reconstruct the original matrix from the decomposed components and compare the
#  reconstructed matrix with the original one.
#  c. Implement a low-rank approximation by retaining only the top-k singular values and
#  observe how the reconstruction error changes with different values of k.


import numpy as np

def perform_svd(matrix):
    # a. Perform SVD decomposition
    U, S, Vt = np.linalg.svd(matrix, full_matrices=False)
    Sigma = np.diag(S)
    
    print("U matrix:\n", U)
    print("\nSigma matrix:\n", Sigma)
    print("\nV^T matrix:\n", Vt)
    
    # b. Reconstruct the original matrix from U, Σ, and V^T
    reconstructed_matrix = np.dot(U, np.dot(Sigma, Vt))
    
    print("\nReconstructed Matrix:\n", reconstructed_matrix)
    
    # Compare the original matrix with the reconstructed matrix
    reconstruction_error = np.linalg.norm(matrix - reconstructed_matrix)
    print("\nReconstruction Error (Full Rank):", reconstruction_error)
    
    return U, S, Vt

def low_rank_approximation(U, S, Vt, k):
    # Create a low-rank approximation by retaining only the top-k singular values
    Sigma_k = np.diag(S[:k])
    U_k = U[:, :k]
    Vt_k = Vt[:k, :]
    
    # Reconstruct the matrix using only the top-k singular values
    reconstructed_matrix_k = np.dot(U_k, np.dot(Sigma_k, Vt_k))
    
    return reconstructed_matrix_k

def calculate_reconstruction_error(original_matrix, reconstructed_matrix):
    # Calculate the Frobenius norm of the difference between the original and reconstructed matrices
    error = np.linalg.norm(original_matrix - reconstructed_matrix, ord='fro')
    return error

# Example Usage:
A = np.array([[1, 2, 3],
              [4, 5, 6],
              [7, 8, 9],
              [10, 11, 12]])

# Perform SVD on the matrix A
U, S, Vt = perform_svd(A)

# Test different values of k for low-rank approximation
k_values = [1, 2, 3]

for k in k_values:
    reconstructed_A_k = low_rank_approximation(U, S, Vt, k)
    error = calculate_reconstruction_error(A, reconstructed_A_k)
    
    print(f"\nReconstructed Matrix (k={k}):\n", reconstructed_A_k)
    print(f"Reconstruction Error (k={k}):", error)
