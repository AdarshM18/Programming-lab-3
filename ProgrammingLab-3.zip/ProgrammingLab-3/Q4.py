# Download the book rating dataset (Link). Write functions to perform following:
#  a. Load the books.csv and ratings.csv into two separate DataFrames using pandas.
#  b. Display the first 10 rows of each data frame.
#  c. Calculate the average rating for each book and find the top 5 highest-rated books.
#  d. Find the number of books published each year.
#  e. Filter out books with fewer than 50 ratings.
#  f. Find the user who has rated the most books.
#  g. Extract the top 5 authors who have written the most books.
#  h. Convert the rating column into a NumPy array and compute the ratings’ mean, me
#  dian, and mode.
#  i. Normalize the ratings with a mean of 0 and a standard deviation 1.
#  j. Create a user-item matrix (R) where each row represents a user, each column repre
#  sents a book, and the values are the ratings.
#  k. ComputethecovariancematrixforRtoidentifycorrelationsbetweenusersorbooks.
#  l. Using R, calculate the cosine similarity between users or books.



import pandas as pd
import numpy as np
from scipy import stats
from sklearn.metrics.pairwise import cosine_similarity

# Load the CSV files into DataFrames
books_df = pd.read_csv('books.csv')
ratings_df = pd.read_csv('ratings.csv')

# Display the first few rows to confirm
print(books_df.head(10))
print(ratings_df.head(10))

# Calculate the average rating for each book
average_ratings = ratings_df.groupby('book_id')['rating'].mean()

# Merge the average ratings with the books DataFrame
books_with_ratings = books_df.merge(average_ratings, left_on='id', right_on='book_id')

# Sort by average rating and display the top 5 highest-rated books
top_5_books = books_with_ratings.sort_values(by='rating', ascending=False).head(5)
print(top_5_books[['title', 'rating']])

# Count the number of books published each year
books_per_year = books_df['original_publication_year'].value_counts().sort_index()
print(books_per_year)

# Count the number of ratings per book
ratings_count = ratings_df['book_id'].value_counts()

# Filter books with fewer than 50 ratings
books_with_sufficient_ratings = books_df[books_df['id'].isin(ratings_count[ratings_count >= 50].index)]
print(books_with_sufficient_ratings)

# Count the number of ratings per user
user_rating_counts = ratings_df['user_id'].value_counts()

# Find the user who has rated the most books
top_user = user_rating_counts.idxmax()
top_user_ratings = user_rating_counts.max()
print(f"User {top_user} has rated the most books: {top_user_ratings} ratings")

# Count the number of books per author
author_counts = books_df['authors'].value_counts()

# Display the top 5 authors with the most books
top_5_authors = author_counts.head(5)
print(top_5_authors)

# Convert ratings to a NumPy array
ratings_array = ratings_df['rating'].to_numpy()

# Compute mean, median, and mode
mean_rating = np.mean(ratings_array)
median_rating = np.median(ratings_array)

mode_result = stats.mode(ratings_array)
mode_rating = mode_result[0]

print(f"Mean: {mean_rating}, Median: {median_rating}, Mode: {mode_rating}")

# Standardize the ratings
ratings_standardized = (ratings_array - mean_rating) / np.std(ratings_array)
print(ratings_standardized)

# Handle duplicate user_id, book_id pairs by aggregating the ratings
ratings_df_aggregated = ratings_df.groupby(['user_id', 'book_id']).agg({'rating': 'mean'}).reset_index()

# Create a user-item matrix
R = ratings_df_aggregated.pivot(index='user_id', columns='book_id', values='rating').fillna(0)
print(R)

# Compute the covariance matrix for the user-item matrix
covariance_matrix = np.cov(R, rowvar=False)
print(covariance_matrix)

# Calculate cosine similarity between users
user_similarity = cosine_similarity(R)

# Calculate cosine similarity between books (transpose R)
book_similarity = cosine_similarity(R.T)

print(user_similarity)
print(book_similarity)

