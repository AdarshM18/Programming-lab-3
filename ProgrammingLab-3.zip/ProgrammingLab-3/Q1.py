import numpy as np

def process_array(A):
    # Part a: Calculate the minimum, maximum, median, mean, and standard deviation of A
    min_val = np.min(A)
    max_val = np.max(A)
    median_val = np.median(A)
    mean_val = np.mean(A)
    std_dev_val = np.std(A)
    
    print(f"Minimum: {min_val}")
    print(f"Maximum: {max_val}")
    print(f"Median: {median_val}")
    print(f"Mean: {mean_val}")
    print(f"Standard Deviation: {std_dev_val}")
    
    # Part b: Compute the mean and variance of A along the first dimension
    mean_along_dim = np.mean(A, axis=0)
    var_along_dim = np.var(A, axis=0)
    
    print(f"Mean along first dimension: {mean_along_dim}")
    print(f"Variance along first dimension: {var_along_dim}")
    
    # Normalize and standardize A
    A_min = np.min(A, axis=0)
    A_max = np.max(A, axis=0)
    
    A_normalized = (A - A_min) / (A_max - A_min)
    A_standardized = (A - mean_along_dim) / np.sqrt(var_along_dim)
    
    print("Normalized Array:\n", A_normalized)
    print("Standardized Array:\n", A_standardized)
    
    return A_normalized, A_standardized

# Example usage:
np.random.seed(0)  # For reproducibility
A = np.random.rand(5, 4)  # Generate a random 2D array of shape (5, 4)
normalized_A, standardized_A = process_array(A)
