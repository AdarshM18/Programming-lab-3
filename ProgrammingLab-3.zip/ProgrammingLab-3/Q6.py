#  LoadanimageusingOpenCV.ConverttheimagetoaNumPyarray. Writethecodesnippet
#  to perform the following operations:
#  a. Calculate Mean, Standard deviation, Minimum and maximum pixel values of the
#  image pixel intensities.
#  b. Plot the histogram of pixel intensities using Matplotlib.
#  c. Resize the image to half of its original dimensions using NumPy operations.
#  d. Perform a rotation of 90 degrees clockwise on the resized image.
#  e. Display the original, resized, and rotated images side by side using Matplotlib.
#  f. Perform SVD (employed in Question 5) on the image matrix.
#  g. Retain only the top-k singular values (e.g., 10, 20, 50) and their corresponding vec
#  tors to reconstruct a compressed version of the image.
#  h. Plot the original image and the compressed versions using Matplotlib.


import cv2
import numpy as np
import matplotlib.pyplot as plt

# Load the image using OpenCV
image = cv2.imread('image.jpg', cv2.IMREAD_GRAYSCALE)  # Load as grayscale

if image is None:
    print("Error: Could not load the image. Please check the file path.")
else:

    # a. Calculate Mean, Standard deviation, Minimum and maximum pixel values of the image pixel intensities.

    mean_val = np.mean(image)
    std_dev = np.std(image)
    min_val = np.min(image)
    max_val = np.max(image)

    print(f"Mean: {mean_val}")
    print(f"Standard Deviation: {std_dev}")
    print(f"Minimum Pixel Value: {min_val}")
    print(f"Maximum Pixel Value: {max_val}")

    # b. Plot the histogram of pixel intensities using Matplotlib
    plt.figure()
    plt.hist(image.ravel(), bins=256, range=[0,256])
    plt.title('Histogram of Pixel Intensities')
    plt.xlabel('Pixel Intensity')
    plt.ylabel('Frequency')
    plt.show()

    # c. Resize the image to half of its original dimensions using NumPy operations
    half_size_image = image[::2, ::2]  # Downsample by taking every second pixel

    # d. Perform rotation of 90 degrees clockwise on the resized image
    rotated_image = np.rot90(half_size_image, k=-1)

    # e. Display the original, resized, and rotated images side by side using Matplotlib
    plt.figure(figsize=(12, 4))

    plt.subplot(1, 3, 1)
    plt.imshow(image, cmap='gray')
    plt.title('Original Image')
    plt.axis('off')

    plt.subplot(1, 3, 2)
    plt.imshow(half_size_image, cmap='gray')
    plt.title('Resized Image (Half Size)')
    plt.axis('off')

    plt.subplot(1, 3, 3)
    plt.imshow(rotated_image, cmap='gray')
    plt.title('Rotated Image (90° CW)')
    plt.axis('off')

    plt.show()

    # f. Perform SVD on the image matrix
    U, S, Vt = np.linalg.svd(image, full_matrices=False)

    # g. Retain only the top-k singular values and reconstruct the image
    def reconstruct_image(U, S, Vt, k):
        S_k = np.diag(S[:k])
        U_k = U[:, :k]
        Vt_k = Vt[:k, :]
        return np.dot(U_k, np.dot(S_k, Vt_k))

    # Choose values for k
    k_values = [10, 20, 50]

    # Plot the original and compressed images side by side
    plt.figure(figsize=(15, 5))

    plt.subplot(1, len(k_values) + 1, 1)
    plt.imshow(image, cmap='gray')
    plt.title('Original Image')
    plt.axis('off')

    for i, k in enumerate(k_values):
        compressed_image = reconstruct_image(U, S, Vt, k)
        
        plt.subplot(1, len(k_values) + 1, i + 2)
        plt.imshow(compressed_image, cmap='gray')
        plt.title(f'Compressed Image (k={k})')
        plt.axis('off')

    plt.show()
